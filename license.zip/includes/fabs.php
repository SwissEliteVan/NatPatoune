 <!-- Boutons flottants -->
    <div class="fab-container">
        <button onclick="window.scrollTo({top: 0, behavior: 'smooth'})" class="fab-btn btn-top" id="backToTopBtn" aria-label="Haut de page">
            <i class="fas fa-chevron-up"></i>
        </button>
        <a href="tel:+41787685047" class="fab-btn btn-phone" aria-label="Appeler"><i class="fas fa-phone"></i></a>
        <a href="https://wa.me/41787685047" target="_blank" rel="noopener noreferrer" class="fab-btn btn-whatsapp" aria-label="WhatsApp"><i class="fab fa-whatsapp"></i></a>
    </div>