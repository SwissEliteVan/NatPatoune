    <!-- Message offline (Service Worker) -->
    <div class="offline-message" id="offlineMessage">
        <i class="fas fa-wifi mr-2"></i>Vous êtes hors ligne. Certaines fonctionnalités peuvent être limitées.
    </div>