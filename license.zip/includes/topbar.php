 <!-- Barre supérieure -->
    <div class="bg-brand-purple text-white py-2 text-xs font-medium relative z-20">
        <div class="container mx-auto px-4 flex justify-between items-center">
            <span class="hidden md:inline"><i class="fas fa-map-marker-alt mr-2 text-brand-pink"></i> Morges, Ouest lausannois, Lausanne et Échallens</span>
            <a href="mailto:miaou@nat-patoune.ch" class="hover:text-brand-pink transition top-email font-bold ml-auto md:ml-0 email-protect">Contact</a>
        </div>
    </div>
